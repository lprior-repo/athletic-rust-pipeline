# Parser-envelope evidence proposal

Root owns source, command execution, commits, and publication. This directory owns evidence preparation only.

The proposed portable documentation is under `docs-ready/docs/verification/`. Start with `docs-ready/docs/verification/2026-10-14-parser-envelope.md`. Copying these files into the repository is a Root decision; nothing here has been committed or published by the assembler.

The source snapshot has 38 paths: 36 original proposal paths and two separately integrated shared files. The original frozen proposal, review, shared integration patches, and separate seven-expectation compile correction are preserved. No compiler/test command was run by the assembler. Running logs are not frozen as final evidence.

Status is provisional. Further command results are awaited. The 38-path source snapshot is bound byte-for-byte to commit `771072a1013017a4f8b4993751f801df16f789a2`. Full release/specification acceptance is not claimed.
