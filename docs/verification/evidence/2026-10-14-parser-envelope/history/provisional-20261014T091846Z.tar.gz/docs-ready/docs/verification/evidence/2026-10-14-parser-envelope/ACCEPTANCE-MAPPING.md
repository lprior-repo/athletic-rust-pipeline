# Requirement-to-evidence mapping

The adopted [contract](contract/PARSER-ENVELOPE.md), implementation [contract/limits](proposal/CONTRACT.md), and [independent review](review/REVIEW.md) define this narrow slice. [acceptance-map.json](acceptance-map.json) gives source/test pointers. All source paths below refer to preserved `source/crates/census-crawl/src/` unless specified otherwise.

| Requirement | Implementation and independent review | Execution or negative API oracle | Current evidence |
|---|---|---|---|
| Seal captured bytes and retained provenance; forbid recombination | `net/acquisition.rs`, retained `read.rs`/`session.rs`/`retention.rs`; review PE-1 | API probes 02–07, retained producer regressions | Static review; probes NOT RUN; tests pending |
| Derive verdict from the intact acquired body through one owner | `milesplit/owned/outcome.rs`; `fetch.rs` and `owned/effect.rs`; review PE-2 | Named sealed-byte/metadata regression; API probes 02–05 | Static review; execution pending |
| Resource refusal returns original retained envelope/allocation | `outcome.rs` resource transition and both existing retention paths; review PE-2 | Named exact ArrayValues/locator/retention/pointer regression and existing resource-parity tests | Static review; execution pending |
| Reject historical/durable incompatibility before parsing or journal effects | `outcome.rs::require_capture_context`; review PE-4 limitation | Both exact `CacheOccurrenceMismatch` tests | Static review; execution pending; no exact arbitrary-context identity guarantee |
| Release resident body without altering metadata/verdict or returning transport authority | `outcome.rs::release_body`, `results/run/acquired.rs`; review PE-2 | Byte/metadata release regression; two existing bounded-buffer regressions | Static review; execution pending; no performance claim |
| Erased raw capture remains untrusted | Both consuming `into_capture` methods | Historical reentry regression; API probes 04–06 | Static review; execution pending |
| Synthetic verdict fixture is historical-only and absent from production | `#[cfg(test)]` outcome factory and migrated unit fixtures; review PE-3 | Sixth named regression; external and production-MileSplit absence probes 04/08 | Definition/source evidence; execution pending |
| Preserve actual production owner/work binding without broadening variant-only guard | Immediate same-context acquisition/interpreter calls; review caller-chain context files | Acquisition target/store/grant and durable replay regression families | Source caller trace; no general envelope-to-context witness claim |
| Preserve M1 shared-file archive-lock behavior and caller migration | Shared patches and source pins; `DELTA-COVERAGE.md` | Acquisition/lock-order regressions and normal all-target compilation | Static integration evidence; execution pending |
| Preserve historical/error/receipt payloads and persisted contracts | Unchanged raw serde plus accessor-only persistence writers; review persistence section | Exact malformed/resource/partial/revision/receipt replay tests in `review/REGRESSIONS.md` | Static sameness only; no executed byte certificate yet |
| Preserve legitimate public read/raw-parser API while rejecting forbidden construction/mutation | `review/API-CHECKS.md` | Positive API probe 01 plus negative probes 02–08 | All eight NOT RUN |
| Record exact failed/pending/passing command outcomes and final source | `raw/`, command receipts, source pins, gate status | Focused test lane, fmt/check/lint/scans, final commit match | Two formatter passes plus format-check/lint/check passes, four compiler failures; fifth attempt pending; API probes and remaining source gates NOT RUN |

## Six definitions are not six passes

The six exact regression names and concrete oracles are retained in [TEST-COVERAGE.json](TEST-COVERAGE.json). They use actual local TLS transport and a qualification store. The first four focused invocations never reached test execution; the fifth is pending. No executed count or passing count is fabricated from the definitions or the requested selector.

The [eight compiler snippets](API-PROBE-STATUS.json) have expected outcomes only. Probe 01 must compile; 02–08 must reject their specified forbidden expressions for the documented privacy/type reason. One unrelated compiler failure does not satisfy any negative probe, and all-target compilation alone does not show that forbidden APIs fail.

## Historical compatibility and authority

Exact payload equality for the selected regression scenarios, once executed, remains narrower than proving that every historical store or every external Rust consumer is compatible. The runtime envelope types are not serialized. `FetchOutcome` serialization, journal keys/phases/payloads, manifests/chunks, receipts, schemas and policy identifiers are not intentionally changed. Rust field construction/mutation is intentionally removed, so semver-compatible Rust source API behavior is not claimed.
