# Parser-envelope evidence decision

STATUS: UNVERIFIED

The original f5b3988 proposal, separate compile correction, both shared-file deltas, independent review, six named test definitions, eight unexecuted compiler probes and exact 38-path commit-bound integrated source are preserved. First-run type errors and second-, third- and fourth-run SIGKILL remain fully visible with terminal outputs and Root command attestations.

This proposal is ready for evidence review and incremental refresh, not for an unconditional acceptance claim. The first four focused runs failed before test execution; the fifth is pending. Format-check, source lint and all-target check passed. API probes and remaining source gates are not run. Source commit is now bound to `771072a1013017a4f8b4993751f801df16f789a2`; all 38 copied files match its exact bytes. The required active-context truth-serum audit is unavailable and not run.

No full specification, historical-all-stores, release, census or publication approval is claimed. Root's final acceptance must remain narrower than the results it actually executes and the authority limitations in `LIMITS.md`.
