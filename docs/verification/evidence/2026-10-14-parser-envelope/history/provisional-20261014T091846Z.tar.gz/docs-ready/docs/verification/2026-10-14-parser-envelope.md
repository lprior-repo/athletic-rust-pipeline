# 2026-10-14 parser-envelope evidence

Status: **UNVERIFIED; fifth focused attempt pending.** This records one persistence-neutral Rust ownership/API slice, not release qualification, full specification verification, census completion, or publication approval.

The [portable evidence bundle](evidence/2026-10-14-parser-envelope/README.md) preserves the original proposal, review, exact 38-path integrated source snapshot, shared-file deltas, compile repair, command receipts and raw terminal logs. The [acceptance mapping](evidence/2026-10-14-parser-envelope/ACCEPTANCE-MAPPING.md) and [limits](evidence/2026-10-14-parser-envelope/LIMITS.md) distinguish source review from executed evidence.

Observed sequence so far:

1. Root's first formatter invocation passed.
2. First focused test invocation failed at compilation: seven `E0308` errors compared `HashSet<String>` journal-key results to `Vec<String>` expectations. Outer exit was 1 and internal Cargo exit was 101. No tests executed.
3. Root corrected exactly those seven expected empty collections and formatted again successfully. The original proposal remains unchanged; the correction is separately pinned.
4. Second focused invocation failed at compilation when the `census-crawl` lib-test rustc process received signal 9 (`SIGKILL`). Outer exit was 1 and internal Cargo exit was 101. No tests executed. The cause is unverified.
5. Third focused invocation also failed at compilation with rustc `SIGKILL`, outer exit 1 and internal Cargo exit 101. No tests executed. The intended `CARGO_PROFILE_TEST_DEBUG=0` override did not take effect: the raw compiler command still used `debuginfo=line-tables-only`. It is not evidence of lowered-debug compilation.
6. Fourth focused invocation failed with rustc `SIGKILL`, outer exit 1 and internal Cargo exit 101. No tests executed. Explicit `--config 'profile.test.debug=0'` took effect: the raw compiler command omitted `debuginfo=line-tables-only` and included `strip=debuginfo`. Source and selected tests remained unchanged. The cause of termination is still unverified.

7. Fifth focused invocation is running with the same source and selected tests, explicit `--config 'profile.test.debug=0'` and `RUSTFLAGS='-Z threads=1'`. Its terminal result is pending; no test pass is inferred from dependency compilation.

All eight compiler API probes are prepared but NOT RUN. Format-check passed (outer exit 0, `fmt-check-first.log`). Source lint and all-target check also passed, with command exits 0 and serial-session outer exit 0 (`lint-first.log`, `check-first.log`). Remaining scoped source gates are NOT RUN in this slice. The recovered evidence-packaging skill requires an active-context truth-serum audit, but its skill/tool is unavailable here; manual artifact auditing does not substitute for that required audit.

The context guard checks only historical/durable variants. Exact owner/work identity binding is attributed to the traced current production acquisition-to-interpretation caller chains, not to the guard or descriptive provenance view. This intentionally tightens the Rust source API and introduces no persisted migration or new persisted protocol.

Source provenance: original proposal base `49ad9922a9ba24148bd4e73dbb46993ee7f39fce`; M1 integration source base `0cde4e29ffbb95baa4d427b460a31dc0925dfd71`; observed evidence-only HEAD `7996734d87d0305eb8bb2060d5e65199cee95a6e`. Parser-envelope source commit is `771072a1013017a4f8b4993751f801df16f789a2` (tree `1a811cfe9328a4e3eaf7b923f2c18671c540aaef`); all 38 source paths match the committed bytes.
