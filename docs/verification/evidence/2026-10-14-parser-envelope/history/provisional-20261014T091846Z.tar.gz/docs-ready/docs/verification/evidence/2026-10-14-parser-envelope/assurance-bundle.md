# Scoped parser-envelope assurance bundle

STATUS: UNVERIFIED

This is a detached evidence proposal. Root owns final integration and acceptance. The [requirement mapping](ACCEPTANCE-MAPPING.md), [machine-readable map](acceptance-map.json), [gate ledger](GATE-STATUS.json), [source pins](SOURCE-PINS.json), [API states](API-PROBE-STATUS.json) and [limits](LIMITS.md) are integral to this bundle.

## Review findings and disposition

| Finding | Recorded disposition | Evidence class and remaining limitation |
|---|---|---|
| PE-1 capture/provenance recombination | `fixed_with_evidence` in preserved review | Static source only; compiler/API execution remains pending |
| PE-2 caller verdict/resource ownership | `fixed_with_evidence` in preserved review | Static source only; behavior and compiler/API execution remain pending |
| PE-3 synthetic historical authority | `fixed_with_evidence` in preserved review | Static source plus sixth test definition; no executed regression yet |
| PE-4 same-variant arbitrary internal context | `owner_approved_no_action` in preserved review | Root expressly retained variant-only scope; exact binding belongs only to traced production callers |
| PE-COMPILE-1 seven empty-journal collection mismatches | `fixed_with_evidence` limited to detached/source correction | All original E0308 diagnostics preserved; exact seven changes pinned; runtime acceptance pending |
| PE-EXEC-2 compiler process SIGKILL | `blocker` | Second, third and fourth focused runs failed; causes unverified; no behavior tests executed |
| PE-EXEC-PENDING executable scoped acceptance | `blocker` | First four focused attempts failed before execution; fifth pending; format-check/lint/check passed; API probes and remaining source gates not run |
| PE-PINS-PENDING final source commit | `fixed_with_evidence` | Source commit `771072a1013017a4f8b4993751f801df16f789a2` and tree are verified; all 38 paths match their snapshot bytes |
| PE-AUDIT-MISSING active-context truth-serum | `blocker` | Required skill/tool unavailable; manual artifact integrity audit is not substituted |

The historical review's `fixed_with_evidence` dispositions explicitly state static evidence class and are not upgraded to runtime proof. No review finding is silently omitted. No behavioral waiver or scope expansion is inferred.

## Commands and raw evidence

`raw/root-command-receipts.json` retains exact Root-observed invocations, setup, session IDs and terminal outer statuses. Completed logs retain the actual outputs. First and second format writes and subsequent format-check, source lint and all-target check passed. First focused invocation failed with seven type mismatches; second, third and fourth failed with SIGKILL. The third invocation's environment debug override was ineffective: its raw compiler command still used `debuginfo=line-tables-only`. The fourth invocation's explicit forwarded `--config 'profile.test.debug=0'` took effect (no line-tables-only argument; `strip=debuginfo` present), but compilation still failed. The fifth invocation is pending with the same selector and explicit debug setting plus `RUSTFLAGS='-Z threads=1'`; no behavior pass is inferred from its build progress. [GATE-STATUS.json](GATE-STATUS.json) is the current command index.

Prepared test/probe commands in historical documents are plans, not evidence of execution. The six new tests and the broader producer/persistence/resource/buffer families must be reconciled to actual terminal output before their mapped requirements can be marked executed. Eight API probes require their exact intended outcomes, not generic failure.

## Proof and wider release evidence

No formal proof, mutation/fuzz/benchmark campaign, native fault lane or release acceptance was executed by this assembler. Existing parser semantics and parser budgets are not rewritten in this slice. Repository release obligations remain distinct. The repository's owner-retired mandatory mutation campaign is not reinstated here, but neither is mutation resistance claimed as executed evidence.

## Artifact audit

The active assembler checks scoped hashes, file existence, JSON parseability, proposed source delta coverage, preservation of failed logs and status distinctions. Results are retained in `ARTIFACT-AUDIT.json`. This audit does not run repository commands or replace the unavailable truth-serum skill. See [truth-serum-report.md](truth-serum-report.md) and [final-evidence-decision.md](final-evidence-decision.md).
