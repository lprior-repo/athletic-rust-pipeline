use crate::milesplit::{roster_entities, RosterRejectionKind, RosterVerdict, Site, SourceRowLocator};
use census_domain::model::{GradYear, SchoolYear, SourceNamespace};
use census_domain::UsJurisdiction;
use std::collections::BTreeSet;

type TestResult<T = ()> = Result<T, Box<dyn std::error::Error>>;

mod fixture;
mod projection;

#[test]
fn genuine_partial_fixture_preserves_all_ordered_dispositions_and_disjoint_known_rejections() -> TestResult {
    let packet = fixture::packet()?;
    let checked = packet.read_semantic_contract(
        crate::participation_evidence::provider_school::PROVIDER_SCHOOL_SEMANTIC_CONTRACT_V1,
    )?;
    let RosterVerdict::Partial { roster, rejected, unfinished } = checked.roster_verdict() else {
        return Err("genuine original roster must remain Partial".into());
    };
    check!(unfinished.is_none());
    check!(eq; roster.athletes.len(), 146);
    check!(eq; rejected.len(), 18);
    let mut admitted_ids = BTreeSet::new();
    let mut rejected_ids = BTreeSet::new();
    let mut rows = Vec::new();
    for member in &roster.athletes {
        check!(admitted_ids.insert(member.athlete().athlete_id.as_str()));
        let raw = fixture::span(member.locator())?;
        check!(raw.contains(&member.athlete().profile_url));
        rows.push((member.locator(), false));
    }
    for rejection in rejected {
        check!(eq; rejection.kind, RosterRejectionKind::InvalidGraduationYear);
        let id = rejection.athlete_id.as_deref().ok_or("known rejected provider identity required")?;
        check!(!id.is_empty());
        check!(rejected_ids.insert(id));
        check!(!admitted_ids.contains(id));
        let raw = fixture::span(rejection.row)?;
        check!(raw.contains(&format!("/athletes/{id}-")));
        check!(raw.contains("column-grad-year"));
        rows.push((rejection.row, true));
    }
    rows.sort_by_key(|(row, _)| row.ordinal);
    check!(eq; rows.len(), 164);
    check!(eq; rows.iter().filter(|(_, rejected)| *rejected).count(), 18);
    for (ordinal, (row, _)) in rows.iter().enumerate() {
        check!(eq; row.ordinal, u32::try_from(ordinal)?);
        check!(!fixture::span(*row)?.is_empty());
    }
    check!(rows.windows(2).all(|pair| pair.first().zip(pair.get(1)).is_some_and(|(left, right)| {
        left.0.byte_offset.checked_add(left.0.byte_length).is_some_and(|end| end <= right.0.byte_offset)
    })));
    check!(eq; roster.athletes.iter().filter(|member| member.athlete().grad_year == GradYear::CO2027).count(), 45);
    check!(packet.read_semantic_contract("unregistered-row-local-policy").is_err());
    fixture::original_bytes()?;
    Ok(())
}
