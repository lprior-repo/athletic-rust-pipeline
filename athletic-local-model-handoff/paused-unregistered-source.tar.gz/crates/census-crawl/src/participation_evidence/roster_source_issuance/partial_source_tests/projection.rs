use super::*;
use census_domain::model::{CanonicalAthlete, SourceIdentity};

#[test]
fn genuine_partial_admitted_rows_project_in64_64_18_windows_with_exact_source_ownership() -> TestResult {
    let packet = fixture::packet()?;
    check!(eq; packet.roster().requested_url(), fixture::URL);
    check!(eq; packet.roster().acquired_at().to_rfc3339_opts(chrono::SecondsFormat::Secs, true), fixture::AT);
    check!(eq; packet.roster().body()?, fixture::BODY);
    let checked = packet.read_semantic_contract(
        crate::participation_evidence::provider_school::PROVIDER_SCHOOL_SEMANTIC_CONTRACT_V1,
    )?;
    let RosterVerdict::Partial { roster, rejected, unfinished } = checked.roster_verdict() else {
        return Err("retained partial roster expected".into());
    };
    check!(unfinished.is_none());
    let year = SchoolYear::from_date("2026-10-16").ok_or("original capture school year")?;
    let site = Site::for_jurisdiction(UsJurisdiction::Michigan);
    match roster_entities(&roster.team, &roster.athletes, year, fixture::AT, &site) {
        Err(crate::CrawlError::Resource { resource, requested, limit }) => {
            check!(eq; resource, "roster projection rows");
            check!(eq; requested, 146);
            check!(eq; limit, 64);
        }
        _ => return Err("full admitted population must respect64-row projection bound".into()),
    }
    let rejected_ids = rejected.iter().map(|row| row.athlete_id.as_deref().ok_or("known rejected ID")).collect::<Result<BTreeSet<_>, _>>()?;
    let mut windows = Vec::new();
    let mut projected_ids = BTreeSet::new();
    let mut co2027 = 0usize;
    for entries in roster.athletes.chunks(64) {
        let (school, athletes, teams) = roster_entities(&roster.team, entries, year, fixture::AT, &site)?;
        check!(school.id == checked.school().id);
        check!(eq; athletes.len(), entries.len());
        check!(teams.iter().all(|team| team.school == school.id && team.school_year == year));
        windows.push(entries.len());
        for (member, athlete) in entries.iter().zip(&athletes) {
            let parsed = member.athlete();
            let identity = athlete.identity_in(&SourceNamespace::MilesplitAthlete).ok_or("exact source identity")?;
            check!(identity.id == parsed.athlete_id);
            check!(identity.url.as_deref() == Some(parsed.profile_url.as_str()));
            check!(!rejected_ids.contains(identity.id.as_str()));
            check!(projected_ids.insert(identity.id.clone()));
            check!(athlete.school == school.id);
            check!(athlete.canonical_name == parsed.name);
            check!(eq; athlete.grad_year, parsed.grad_year);
            check!(eq; athlete.gender, parsed.gender);
            let source_identity = SourceIdentity::new(SourceNamespace::MilesplitAthlete, parsed.athlete_id.clone()).with_url(parsed.profile_url.clone());
            check!(athlete.id == CanonicalAthlete::mint(&school.id, &parsed.name, parsed.grad_year, parsed.gender, &source_identity));
            let [graduation] = athlete.published_graduations.as_slice() else {
                return Err("one exact source-published graduation".into());
            };
            check!(eq; graduation.grad_year, parsed.grad_year);
            check!(eq; graduation.source.url.as_deref(), Some(fixture::URL));
            check!(athlete.observed_grades.is_empty());
            check!(athlete.identity_attestations.is_empty());
            let [evidence] = athlete.evidence.as_slice() else {
                return Err("one original profile evidence".into());
            };
            check!(eq; evidence.observed_on, fixture::AT);
            check!(evidence.source.url.as_deref() == Some(parsed.profile_url.as_str()));
            check!(fixture::span(member.locator())?.contains(&parsed.profile_url));
            if athlete.grad_year == GradYear::CO2027 {
                co2027 = co2027.checked_add(1).ok_or("cohort count overflow")?;
            }
        }
    }
    check!(eq; windows, vec![64, 64, 18]);
    check!(eq; projected_ids.len(), 146);
    check!(eq; co2027, 45);
    fixture::original_bytes()?;
    Ok(())
}
