use super::*;
use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(super) struct Enrollment {
    pub(super) schema: String,
    pub(super) command: ResultSchoolEnrollmentCommandV1,
    pub(super) initial_inventory: ResultSchoolInventoryV1,
    pub(super) approval_digest: ResultSchoolDigestV1,
    pub(super) committed_at: DateTime<Utc>,
}

#[derive(Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(super) enum PriorProof {
    IdentityOnly,
    IdentityAndRosterSource { enrollment: Vec<u8>, receipt: Vec<u8> },
}

#[derive(Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(super) struct Proof {
    pub(super) schema: String,
    pub(super) enrollment: Vec<u8>,
    pub(super) receipt: Vec<u8>,
    pub(super) qualification: Vec<u8>,
    pub(super) prior: PriorProof,
}

#[derive(Serialize)]
struct Approval<'a> { schema: &'static str, command: &'a ResultSchoolEnrollmentCommandV1 }

pub(super) fn approval(command: &ResultSchoolEnrollmentCommandV1, grant: &mut AttachmentReplayGrantV1) -> StoreResult<Vec<u8>> {
    validate_command(command)?;
    codec::encode(&Approval { schema: "result-school-enrollment-approval-v1", command }, grant)
}

pub(super) fn initial(command: &ResultSchoolEnrollmentCommandV1, grant: &mut AttachmentReplayGrantV1) -> StoreResult<ResultSchoolInventoryV1> {
    let basis = result_school_digest_v1(command, grant).map_err(Error::Domain)?;
    initial_result_school_inventory_v1(&command.store, &basis, grant).map_err(|error| Error::Domain(error).into())
}

pub(super) fn operation(command: &ResultSchoolEnrollmentCommandV1) -> String { format!("{OPERATIONS}{}", command.operation.as_str()) }

pub(super) fn validate_command(command: &ResultSchoolEnrollmentCommandV1) -> StoreResult<()> {
    if command.version != 1 || command.operation.as_str().len() > 256 || command.operation.as_str().starts_with(NAME) {
        return Err(Error::Corrupt("enrollment command").into());
    }
    Ok(())
}
