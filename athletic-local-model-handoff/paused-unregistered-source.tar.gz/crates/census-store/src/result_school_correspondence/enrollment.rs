use super::*;
use crate::StoreRevision;
use census_domain::evidence_subject_attachment::AttachmentPublicHeadV1;
use census_domain::model::StoreIdentity;
use chrono::{DateTime, Utc};

mod inspect;
mod prepare;
mod apply;
mod replay;

pub struct ResultSchoolEnrollmentInputsV1<'s> {
    revision: StoreRevision<'s>,
    store: StoreIdentity,
    prior: ResultSchoolPriorCapabilityV1,
    token: ResultSchoolDigestV1,
    head: AttachmentPublicHeadV1,
    grant: AttachmentReplayGrantV1,
}

pub struct ResultSchoolEnrollmentReviewV1 {
    pub operation: ResultSchoolTextV1,
    pub actor: ResultSchoolReviewActorV1,
    pub reviewed_at: DateTime<Utc>,
    pub rationale: ResultSchoolTextV1,
}

pub struct PreparedResultSchoolEnrollmentV1<'s> {
    revision: StoreRevision<'s>,
    command: ResultSchoolEnrollmentCommandV1,
    approval: Vec<u8>,
    approval_digest: ResultSchoolDigestV1,
    replay: Option<crate::Receipt>,
    grant: AttachmentReplayGrantV1,
}

impl ResultSchoolEnrollmentInputsV1<'_> {
    pub fn store_identity(&self) -> &StoreIdentity { &self.store }
    pub fn prior_capability(&self) -> &ResultSchoolPriorCapabilityV1 { &self.prior }
    pub fn input_token_digest(&self) -> &ResultSchoolDigestV1 { &self.token }
    pub fn accepted_head(&self) -> &AttachmentPublicHeadV1 { &self.head }
    pub fn evidence_generation(&self) -> u64 { self.revision.evidence_generation() }
    pub fn derived_generation(&self) -> u64 { self.revision.derived_generation() }
}

impl PreparedResultSchoolEnrollmentV1<'_> {
    pub fn approval_bytes(&self) -> &[u8] { &self.approval }
    pub fn approval_digest(&self) -> &ResultSchoolDigestV1 { &self.approval_digest }
    pub fn replay_only(&self) -> bool { self.replay.is_some() }
}
