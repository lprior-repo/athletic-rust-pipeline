use super::*;
use crate::{StoreFormat, StoreIdentity};
use fjall::{Keyspace, Readable, Snapshot};

pub(crate) fn validate_format(snapshot: &Snapshot, meta: &Keyspace, journal: &Keyspace, receipts: &Keyspace, format: &StoreFormat, budget: &mut ResultSchoolStartupValidationBudgetV1) -> StoreResult<()> {
    guarded(&mut budget.grant, |grant| load(snapshot, meta, journal, receipts, format, grant).map(|_| ()))
}

pub(crate) fn preserved_prior_capability(snapshot: &Snapshot, meta: &Keyspace, journal: &Keyspace, receipts: &Keyspace, format: &StoreFormat, budget: &mut ResultSchoolStartupValidationBudgetV1) -> StoreResult<ResultSchoolPriorCapabilityV1> {
    guarded(&mut budget.grant, |grant| {
        let held = load(snapshot, meta, journal, receipts, format, grant)?.ok_or(Error::EnrollmentRequired)?;
        let enrollment: wire::Enrollment = codec::decode(&held.enrollment, grant)?;
        Ok(enrollment.command.prior)
    })
}

pub(super) fn load(snapshot: &Snapshot, meta: &Keyspace, journal: &Keyspace, receipts: &Keyspace, format: &StoreFormat, grant: &mut AttachmentReplayGrantV1) -> StoreResult<Option<wire::Proof>> {
    if format.lifecycle_revision != Some(LIFECYCLE) {
        namespace(snapshot, meta, NAME, &[], grant)?;
        namespace(snapshot, journal, NAME, &[], grant)?;
        namespace(snapshot, receipts, NAME, &[], grant)?;
        return Ok(None);
    }
    if format.schema_version != Some(2) || format.key_format != Some(1) || format.migration_target.is_some() { return Err(Error::EnrollmentRequired.into()); }
    namespace(snapshot, meta, NAME, &[ENROLLMENT], grant)?;
    namespace(snapshot, journal, NAME, &[], grant)?;
    let enrollment = value(snapshot, meta, ENROLLMENT.as_bytes(), grant)?;
    let record: wire::Enrollment = codec::decode(&enrollment, grant)?;
    let operation = wire::operation(&record.command);
    namespace(snapshot, receipts, NAME, &[&operation], grant)?;
    let receipt = value(snapshot, receipts, operation.as_bytes(), grant)?;
    let qualification = crate::public_identity::retained_qualification_declaration_v1(snapshot, meta, grant)?;
    let prior = prior(snapshot, meta, journal, receipts, &record.command.prior, grant)?;
    let proof = wire::Proof { schema: "result-school-enrollment-proof-v1".into(), enrollment, receipt, qualification, prior };
    proof::verify(&proof, &identity(snapshot, journal, grant)?, grant)?;
    Ok(Some(proof))
}

pub(super) fn value(snapshot: &Snapshot, table: &Keyspace, key: &[u8], grant: &mut AttachmentReplayGrantV1) -> StoreResult<Vec<u8>> {
    grant.charge_steps(2).map_err(grant_error)?;
    let length = snapshot.size_of(table, key).map_err(|source| StoreError::Read { source })?.ok_or(Error::Corrupt("missing protected value"))?;
    let length = usize::try_from(length).map_err(|_| Error::BudgetExceeded)?;
    if length > MAX_RESULT_SCHOOL_RECORD_BYTES { return Err(Error::BudgetExceeded.into()); }
    grant.charge_bytes(length.checked_mul(2).and_then(|value| value.checked_add(key.len())).ok_or(Error::BudgetExceeded)?).map_err(grant_error)?;
    let raw = snapshot.get(table, key).map_err(|source| StoreError::Read { source })?.ok_or(Error::Corrupt("missing protected value"))?;
    if raw.len() != length { return Err(Error::Corrupt("protected value size changed").into()); }
    let mut output = Vec::new();
    output.try_reserve_exact(length).map_err(|_| Error::BudgetExceeded)?;
    output.extend_from_slice(&raw);
    Ok(output)
}

pub(super) fn namespace(snapshot: &Snapshot, table: &Keyspace, prefix: &str, expected: &[&str], grant: &mut AttachmentReplayGrantV1) -> StoreResult<()> {
    if expected.len() > 1 { return Err(Error::Corrupt("unsupported enrollment namespace shape").into()); }
    let mut seen = 0;
    let mut rows = snapshot.prefix(table, prefix);
    for _ in 0..2 {
        grant.charge_steps(1).map_err(grant_error)?;
        let Some(row) = rows.next() else {
            return if seen == expected.len() { Ok(()) } else { Err(Error::Corrupt("missing protected namespace key").into()) };
        };
        let key = row.key().map_err(|source| StoreError::Read { source })?;
        grant.charge_bytes(key.len()).map_err(grant_error)?;
        if expected.get(seen).is_none_or(|expected| expected.as_bytes() != key.as_ref()) { return Err(Error::Corrupt("unexpected protected namespace key").into()); }
        seen += 1;
    }
    Err(Error::BudgetExceeded.into())
}

pub(super) fn prior(snapshot: &Snapshot, meta: &Keyspace, journal: &Keyspace, receipts: &Keyspace, capability: &ResultSchoolPriorCapabilityV1, grant: &mut AttachmentReplayGrantV1) -> StoreResult<wire::PriorProof> {
    match capability {
        ResultSchoolPriorCapabilityV1::IdentityOnly { .. } => {
            for table in [meta, journal, receipts] { namespace(snapshot, table, "roster_source_issuance", &[], grant)?; }
            Ok(wire::PriorProof::IdentityOnly)
        }
        ResultSchoolPriorCapabilityV1::IdentityAndRosterSource { .. } => {
            let enrollment = value(snapshot, meta, crate::roster_source_issuance::ENROLLMENT.as_bytes(), grant)?;
            let operation = crate::roster_source_issuance::retained_enrollment_operation_v1(&enrollment, grant)?;
            let receipt = value(snapshot, receipts, operation.as_bytes(), grant)?;
            Ok(wire::PriorProof::IdentityAndRosterSource { enrollment, receipt })
        }
    }
}

pub(super) fn identity(snapshot: &Snapshot, journal: &Keyspace, grant: &mut AttachmentReplayGrantV1) -> StoreResult<StoreIdentity> {
    let key = crate::Store::journal_key("export-lineage-v1", "store-identity");
    let bytes = value(snapshot, journal, &key, grant)?;
    grant.charge_bytes(bytes.len()).map_err(grant_error)?;
    grant.charge_steps(64).map_err(grant_error)?;
    match crate::lineage::read(snapshot, journal)? {
        crate::lineage::RetainedIdentity::Present(identity) => Ok(identity),
        crate::lineage::RetainedIdentity::Absent => Err(Error::Corrupt("origin lineage absent").into()),
    }
}
