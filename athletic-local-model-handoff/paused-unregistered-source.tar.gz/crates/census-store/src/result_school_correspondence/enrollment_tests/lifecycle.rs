use super::*;

#[test]
fn controlled_seven_and_eight_enroll_preserving_original_rows_and_replay() -> TestResult {
    for roster in [false, true] {
        let (_directory, store, _writer) = fixture()?;
        let predecessor = if roster { Some(predecessor::enroll_roster(&store)?) } else { None };
        let before = retained_state(&store)?;
        let inputs = store.inspect_result_school_enrollment_v1(AttachmentReplayGrantV1::new())?;
        check!(eq; inputs.store_identity(), &store.store_identity()?);
        check!(eq; inputs.accepted_head().sequence, 1);
        check!(eq; matches!(inputs.prior_capability(), ResultSchoolPriorCapabilityV1::IdentityAndRosterSource { .. }), roster);
        let prepared = store.prepare_result_school_enrollment_v1(inputs, review()?)?;
        check!(!prepared.replay_only());
        let approval = prepared.approval_bytes().to_vec();
        let digest = prepared.approval_digest().clone();
        check!(eq; retained_state(&store)?, before);
        let first = store.apply_result_school_enrollment_v1(prepared, &approval, &digest)?;
        check!(first.written());
        check!(eq; store.store_format()?.lifecycle_revision, Some(9));
        let after = retained_state(&store)?;
        preserve_original(&before, &after)?;
        let mut grant = AttachmentReplayGrantV1::new();
        let proof = store.read_result_school_enrollment_proof_v1(&mut grant)?;
        let retained = proof.bytes().to_vec();
        drop(proof);
        check!(!retained.is_empty());
        check!(eq; store.read_result_school_enrollment_proof_v1(&mut AttachmentReplayGrantV1::new())?.bytes(), retained.as_slice());
        let replay = store.prepare_result_school_enrollment_replay_v1(
            &review()?.operation, &digest, AttachmentReplayGrantV1::new(),
        )?;
        check!(replay.replay_only());
        check!(eq; replay.approval_bytes(), approval.as_slice());
        let repeated = store.apply_result_school_enrollment_v1(replay, &approval, &digest)?;
        check!(matches!(repeated, Application::Repeated(_)));
        check!(eq; repeated.receipt(), first.receipt());
        check!(eq; retained_state(&store)?, after);
        check!(eq; store.read_result_school_enrollment_proof_v1(&mut AttachmentReplayGrantV1::new())?.bytes(), retained.as_slice());
        if let Some(predecessor) = predecessor {
            let receipt = store.receipt(&format!("roster_source_issuance_v1:{}", predecessor.operation))?
                .ok_or("original roster enrollment receipt missing")?;
            check!(eq; serde_json::to_vec(&receipt)?, predecessor.receipt);
        }
    }
    Ok(())
}

fn preserve_original(
    before: &crate::public_identity_tests::support::PhysicalState,
    after: &crate::public_identity_tests::support::PhysicalState,
) -> TestResult {
    for (table, rows) in before {
        let (_, current) = after.iter().find(|(name, _)| name == table).ok_or("missing keyspace")?;
        for (key, bytes) in rows {
            if table == crate::META && key.as_slice() == crate::format::LIFECYCLE_REVISION_KEY.as_bytes() {
                continue;
            }
            check!(current.iter().any(|(held_key, held)| held_key == key && held == bytes));
        }
        let added = current.iter().filter(|(key, _)| !rows.iter().any(|(old, _)| old == key)).count();
        let expected = usize::from(table == crate::META || table == crate::RECEIPTS);
        check!(eq; added, expected);
    }
    Ok(())
}
