use super::*;
use census_domain::roster_affiliation_authority::RosterAuthorityTextV1;
use crate::roster_source_issuance::{RosterEnrollmentReviewV1, RosterReviewActorV1};
use chrono::DateTime;

pub(super) struct RosterEnrollment {
    pub(super) operation: String,
    pub(super) approval: Vec<u8>,
    pub(super) digest: String,
    pub(super) receipt: Vec<u8>,
}

pub(super) fn enroll_roster(store: &Store) -> TestResult<RosterEnrollment> {
    check!(eq; store.store_format()?.lifecycle_revision, Some(7));
    let operation = "controlled-school-predecessor-eight".to_owned();
    let inputs = store.inspect_roster_source_enrollment_v1()?;
    let prepared = store.prepare_roster_source_enrollment_v1(inputs, RosterEnrollmentReviewV1 {
        operation: RosterAuthorityTextV1::parse(&operation)?,
        actor: RosterReviewActorV1::LocalOperator,
        reviewed_at: DateTime::parse_from_rfc3339("2026-10-17T00:00:00Z")?.to_utc(),
        rationale: RosterAuthorityTextV1::parse("Explicit synthetic predecessor enrollment fixture")?,
    })?;
    let approval = prepared.approval_bytes().to_vec();
    let digest = prepared.approval_digest().to_owned();
    let application = store.apply_roster_source_enrollment_v1(prepared, &approval, &digest)?;
    check!(application.written());
    check!(eq; store.store_format()?.lifecycle_revision, Some(8));
    Ok(RosterEnrollment {
        operation, approval, digest,
        receipt: serde_json::to_vec(application.receipt())?,
    })
}

pub(super) fn advance(store: &Store) -> TestResult {
    store.append(Table::Athletes, &subject("school-enrollment-stale-input", "991901")?)?;
    Ok(())
}

#[test]
fn controlled_predecessor_eight_uses_public_approval_and_exact_replay() -> TestResult {
    let (_directory, store, _writer) = fixture()?;
    let enrolled = enroll_roster(&store)?;
    check!(!enrolled.approval.is_empty());
    advance(&store)?;
    let before = retained_state(&store)?;
    let replay = store.replay_roster_source_enrollment_v1(&enrolled.operation, &enrolled.digest)?;
    check!(matches!(replay, Application::Repeated(_)));
    check!(eq; serde_json::to_vec(replay.receipt())?, enrolled.receipt);
    check!(eq; retained_state(&store)?, before);
    Ok(())
}

#[test]
fn controlled_predecessor_eight_cold_reopen_and_backup_preserve_receipt() -> TestResult {
    let (directory, store, writer) = fixture()?;
    let enrolled = enroll_roster(&store)?;
    store.flush()?;
    let original = retained_state(&store)?;
    drop(writer);
    drop(store);
    let root = directory.path().join("identity");
    let backup = directory.path().join("backup");
    Store::backup(&root, &backup)?;
    let restored = directory.path().join("restored");
    Store::restore(&backup, &restored)?;
    for path in [&root, &restored] {
        let (store, _writer) = Store::open_public_identity_qualification_v3(path)?.into_parts();
        check!(eq; store.store_format()?.lifecycle_revision, Some(8));
        check!(eq; retained_state(&store)?, original);
        let replay = store.replay_roster_source_enrollment_v1(&enrolled.operation, &enrolled.digest)?;
        check!(matches!(replay, Application::Repeated(_)));
        check!(eq; serde_json::to_vec(replay.receipt())?, enrolled.receipt);
        check!(eq; retained_state(&store)?, original);
    }
    Ok(())
}
