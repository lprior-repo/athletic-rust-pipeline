use super::*;
use census_domain::model::StoreIdentity;

mod validate;
pub(super) use validate::verify;

pub struct ResultSchoolEnrollmentProofV1 {
    bytes: Vec<u8>,
}

impl ResultSchoolEnrollmentProofV1 {
    pub fn bytes(&self) -> &[u8] { &self.bytes }
    pub(super) fn from_held(value: &wire::Proof, grant: &mut AttachmentReplayGrantV1) -> StoreResult<Self> {
        Ok(Self { bytes: codec::encode(value, grant)? })
    }
}
