use super::*;
use serde::{de::DeserializeOwned, Serialize};

pub(super) fn encode(value: &(impl Serialize + ?Sized), grant: &mut AttachmentReplayGrantV1) -> StoreResult<Vec<u8>> {
    encode_result_school_model_v1(value, grant).map_err(|error| Error::Domain(error).into())
}
pub(super) fn decode<T: DeserializeOwned + Serialize>(raw: &[u8], grant: &mut AttachmentReplayGrantV1) -> StoreResult<T> {
    if raw.len() > MAX_RESULT_SCHOOL_RECORD_BYTES { return Err(Error::BudgetExceeded.into()); }
    grant.charge_bytes(raw.len()).map_err(grant_error)?;
    grant.charge_steps(1).map_err(grant_error)?;
    let value: T = serde_json::from_slice(raw).map_err(|_| Error::Corrupt("record decoding"))?;
    if encode(&value, grant)? != raw { return Err(Error::Corrupt("noncanonical record").into()); }
    Ok(value)
}
pub(super) fn digest(raw: &[u8], grant: &mut AttachmentReplayGrantV1) -> StoreResult<ResultSchoolDigestV1> {
    grant.charge_steps(raw.len().div_ceil(512).max(1)).map_err(grant_error)?;
    use sha2::{Digest, Sha256};
    ResultSchoolDigestV1::parse(&format!("{:x}", Sha256::digest(raw))).map_err(grant_error)
}
