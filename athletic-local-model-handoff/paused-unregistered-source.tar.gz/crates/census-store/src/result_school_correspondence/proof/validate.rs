use super::*;
use census_domain::public_identity_qualification::PublicIdentityQualificationV3;

pub(in super::super) fn verify(
    proof: &wire::Proof,
    identity: &StoreIdentity,
    grant: &mut AttachmentReplayGrantV1,
) -> StoreResult<()> {
    if proof.schema != "result-school-enrollment-proof-v1" {
        return Err(Error::Corrupt("enrollment proof schema").into());
    }
    let record: wire::Enrollment = codec::decode(&proof.enrollment, grant)?;
    wire::validate_command(&record.command)?;
    let qualification: PublicIdentityQualificationV3 = codec::decode(&proof.qualification, grant)?;
    let approval = wire::approval(&record.command, grant)?;
    if record.schema != "result-school-enrollment-v1"
        || &record.command.store != identity
        || qualification.store_identity() != identity
        || record.command.prior.qualification() != &codec::digest(&proof.qualification, grant)?
        || record.approval_digest != codec::digest(&approval, grant)?
        || record.committed_at < record.command.reviewed_at
        || record.initial_inventory != wire::initial(&record.command, grant)?
    {
        return Err(Error::Corrupt("enrollment proof binding").into());
    }
    prior(&proof.prior, &record.command.prior, identity, grant)?;
    let digest = codec::digest(&proof.enrollment, grant)?;
    let receipt: crate::Receipt = codec::decode(&proof.receipt, grant)?;
    if receipt.operation != wire::operation(&record.command)
        || receipt.digest != digest.as_str()
        || receipt.at != record.committed_at.to_rfc3339()
        || receipt.appended != 0
        || receipt.credited
    {
        return Err(Error::Corrupt("enrollment receipt binding").into());
    }
    Ok(())
}

fn prior(
    proof: &wire::PriorProof,
    prior: &ResultSchoolPriorCapabilityV1,
    identity: &StoreIdentity,
    grant: &mut AttachmentReplayGrantV1,
) -> StoreResult<()> {
    match (proof, prior) {
        (wire::PriorProof::IdentityOnly, ResultSchoolPriorCapabilityV1::IdentityOnly { .. }) => Ok(()),
        (wire::PriorProof::IdentityAndRosterSource { enrollment, receipt },
            ResultSchoolPriorCapabilityV1::IdentityAndRosterSource { roster_enrollment, .. }) => {
            if &codec::digest(enrollment, grant)? != roster_enrollment {
                return Err(Error::Corrupt("prior roster enrollment differs").into());
            }
            crate::roster_source_issuance::validate_roster_enrollment_proof_v1(
                enrollment, receipt, identity, grant,
            )
        }
        _ => Err(Error::Corrupt("prior capability proof differs").into()),
    }
}
