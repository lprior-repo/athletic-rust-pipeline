use super::*;
use crate::{Store, StoreSnapshot};

impl Store {
    pub fn inspect_result_school_enrollment_v1(
        &self,
        mut grant: AttachmentReplayGrantV1,
    ) -> StoreResult<ResultSchoolEnrollmentInputsV1<'_>> {
        let _lock = self.lock_appends();
        let inspected = guarded(&mut grant, |grant| {
            let format = self.store_format()?;
            if !matches!(format.lifecycle_revision, Some(7 | 8))
                || format.schema_version != Some(2)
                || format.key_format != Some(1)
                || format.migration_target.is_some()
            {
                return Err(Error::EnrollmentRequired.into());
            }
            let snapshot = self.db.snapshot();
            read::load(&snapshot, &self.meta, &self.journal, &self.receipts, &format, grant)?;
            let view = self.snapshot_locked();
            let store = read::identity(&snapshot, &self.journal, grant)?;
            let qualification = crate::public_identity::retained_qualification_declaration_v1(
                &snapshot, &self.meta, grant,
            )?;
            let declared: census_domain::public_identity_qualification::PublicIdentityQualificationV3 = codec::decode(&qualification, grant)?;
            if declared.store_identity() != &store { return Err(Error::Corrupt("qualification origin").into()); }
            let qualification = codec::digest(&qualification, grant)?;
            let prior = if format.lifecycle_revision == Some(8) {
                let enrollment = read::value(&snapshot, &self.meta, crate::roster_source_issuance::ENROLLMENT.as_bytes(), grant)?;
                ResultSchoolPriorCapabilityV1::IdentityAndRosterSource {
                    qualification, roster_enrollment: codec::digest(&enrollment, grant)?,
                }
            } else { ResultSchoolPriorCapabilityV1::IdentityOnly { qualification } };
            let retained = read::prior(&snapshot, &self.meta, &self.journal, &self.receipts, &prior, grant)?;
            if let wire::PriorProof::IdentityAndRosterSource { enrollment, receipt } = retained {
                crate::roster_source_issuance::validate_roster_enrollment_proof_v1(&enrollment, &receipt, &store, grant)?;
            }
            let (token, head) = inputs(&view, grant)?;
            Ok((view.revision(), store, prior, token, head))
        })?;
        Ok(ResultSchoolEnrollmentInputsV1 {
            revision: inspected.0, store: inspected.1, prior: inspected.2,
            token: inspected.3, head: inspected.4, grant,
        })
    }
}

pub(super) fn inputs(view: &StoreSnapshot<'_>, grant: &mut AttachmentReplayGrantV1) -> StoreResult<(ResultSchoolDigestV1, AttachmentPublicHeadV1)> {
    grant.charge_bytes(4096).map_err(grant_error)?;
    grant.charge_steps(16).map_err(grant_error)?;
    let token = view.attachment_input_revision_bytes()?;
    let token = codec::digest(&token, grant)?;
    let head = view.attachment_public_head()?;
    let head = AttachmentPublicHeadV1 {
        sequence: head.sequence,
        digest: ResultSchoolDigestV1::parse(&head.digest).map_err(grant_error)?,
    };
    Ok((token, head))
}
