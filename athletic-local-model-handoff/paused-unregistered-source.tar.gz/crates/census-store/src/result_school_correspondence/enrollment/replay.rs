use super::*;
use crate::{Receipt, Store};

impl Store {
    pub fn prepare_result_school_enrollment_replay_v1(
        &self,
        operation: &ResultSchoolTextV1,
        approval_digest: &ResultSchoolDigestV1,
        mut grant: AttachmentReplayGrantV1,
    ) -> StoreResult<PreparedResultSchoolEnrollmentV1<'_>> {
        let _lock = self.lock_appends();
        let (command, approval, receipt) = guarded(&mut grant, |grant| {
            let proof = retained(self, grant)?;
            let record: wire::Enrollment = codec::decode(&proof.enrollment, grant)?;
            if &record.command.operation != operation || &record.approval_digest != approval_digest {
                return Err(Error::OperationConflict.into());
            }
            let approval = wire::approval(&record.command, grant)?;
            let receipt = codec::decode(&proof.receipt, grant)?;
            Ok((record.command, approval, receipt))
        })?;
        Ok(PreparedResultSchoolEnrollmentV1 {
            revision: self.snapshot_locked().revision(), command, approval,
            approval_digest: approval_digest.clone(), replay: Some(receipt), grant,
        })
    }

    pub fn read_result_school_enrollment_proof_v1(
        &self,
        grant: &mut AttachmentReplayGrantV1,
    ) -> StoreResult<ResultSchoolEnrollmentProofV1> {
        let _lock = self.lock_appends();
        guarded(grant, |grant| {
            let value = retained(self, grant)?;
            ResultSchoolEnrollmentProofV1::from_held(&value, grant)
        })
    }
}

pub(super) fn require_retained(
    store: &Store,
    command: &ResultSchoolEnrollmentCommandV1,
    digest: &ResultSchoolDigestV1,
    expected_receipt: &Receipt,
    grant: &mut AttachmentReplayGrantV1,
) -> StoreResult<Receipt> {
    let proof = retained(store, grant)?;
    let record: wire::Enrollment = codec::decode(&proof.enrollment, grant)?;
    let receipt: Receipt = codec::decode(&proof.receipt, grant)?;
    if &record.command != command || &record.approval_digest != digest
        || codec::encode(&receipt, grant)? != codec::encode(expected_receipt, grant)?
    { return Err(Error::OperationConflict.into()); }
    Ok(receipt)
}

fn retained(store: &Store, grant: &mut AttachmentReplayGrantV1) -> StoreResult<wire::Proof> {
    read::load(&store.db.snapshot(), &store.meta, &store.journal, &store.receipts,
        &store.store_format()?, grant)?.ok_or_else(|| Error::EnrollmentRequired.into())
}
