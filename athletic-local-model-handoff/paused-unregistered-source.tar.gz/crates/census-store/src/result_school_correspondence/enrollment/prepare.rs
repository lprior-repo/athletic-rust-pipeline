use super::*;
use crate::Store;

impl Store {
    pub fn prepare_result_school_enrollment_v1<'s>(
        &'s self,
        inputs: ResultSchoolEnrollmentInputsV1<'s>,
        review: ResultSchoolEnrollmentReviewV1,
    ) -> StoreResult<PreparedResultSchoolEnrollmentV1<'s>> {
        let ResultSchoolEnrollmentInputsV1 { revision, store, prior, token, head, mut grant } = inputs;
        let _lock = self.lock_appends();
        let command = ResultSchoolEnrollmentCommandV1 {
            version: 1, store, prior, input_token: token, accepted_head: head,
            evidence_generation: revision.evidence_generation(),
            derived_generation: revision.derived_generation(),
            operation: review.operation, actor: review.actor,
            reviewed_at: review.reviewed_at, rationale: review.rationale,
        };
        let (approval, approval_digest) = guarded(&mut grant, |grant| {
            revision.ensure_origin(self, command.operation.as_str())?;
            require_current(self, &revision, &command, grant)?;
            let approval = wire::approval(&command, grant)?;
            let digest = codec::digest(&approval, grant)?;
            Ok((approval, digest))
        })?;
        Ok(PreparedResultSchoolEnrollmentV1 { revision, command, approval, approval_digest, replay: None, grant })
    }
}

pub(super) fn require_current(
    store: &Store,
    revision: &StoreRevision<'_>,
    command: &ResultSchoolEnrollmentCommandV1,
    grant: &mut AttachmentReplayGrantV1,
) -> StoreResult<()> {
    wire::validate_command(command)?;
    revision.ensure_current(store, command.operation.as_str())?;
    let format = store.store_format()?;
    if format.lifecycle_revision != Some(command.prior.lifecycle())
        || format.schema_version != Some(2) || format.key_format != Some(1)
        || format.migration_target.is_some()
    { return Err(Error::InputMoved.into()); }
    let snapshot = store.db.snapshot();
    read::load(&snapshot, &store.meta, &store.journal, &store.receipts, &format, grant)?;
    let qualification = crate::public_identity::retained_qualification_declaration_v1(&snapshot, &store.meta, grant)?;
    if &codec::digest(&qualification, grant)? != command.prior.qualification()
        || read::identity(&snapshot, &store.journal, grant)? != command.store
    { return Err(Error::InputMoved.into()); }
    let prior = read::prior(&snapshot, &store.meta, &store.journal, &store.receipts, &command.prior, grant)?;
    if let wire::PriorProof::IdentityAndRosterSource { enrollment, receipt } = prior {
        let ResultSchoolPriorCapabilityV1::IdentityAndRosterSource { roster_enrollment, .. } = &command.prior else { return Err(Error::InputMoved.into()); };
        if &codec::digest(&enrollment, grant)? != roster_enrollment { return Err(Error::InputMoved.into()); }
        crate::roster_source_issuance::validate_roster_enrollment_proof_v1(&enrollment, &receipt, &command.store, grant)?;
    }
    let (token, head) = super::inspect::inputs(&store.snapshot_locked(), grant)?;
    if token != command.input_token || head != command.accepted_head
        || revision.evidence_generation() != command.evidence_generation
        || revision.derived_generation() != command.derived_generation
    { return Err(Error::InputMoved.into()); }
    Ok(())
}
