use super::super::{codec, RosterSourceIssuanceStoreError as Error, ENROLLMENT, OPERATION_PREFIX};
use super::*;
use crate::public_identity_tests::support::{fixture, retained_state, TestResult};
use crate::{Receipt, Store, StoreError};
use census_domain::evidence_subject_attachment::{
    AttachmentReplayGrantV1 as Grant, EvidenceSubjectAttachmentError,
};
use census_domain::public_identity_history::ReplayLimits;
use fjall::Readable;

fn enrolled() -> TestResult<(tempfile::TempDir, Store, Vec<u8>, Vec<u8>)> {
    let (directory, store, _writer) = fixture()?;
    let inputs = store.inspect_roster_source_enrollment_v1()?;
    let prepared = store.prepare_roster_source_enrollment_v1(
        inputs,
        RosterEnrollmentReviewV1 {
            operation: RosterAuthorityTextV1::parse("controlled-retained-proof")?,
            actor: RosterReviewActorV1::LocalOperator,
            reviewed_at: DateTime::parse_from_rfc3339("2026-01-01T00:00:00Z")?.to_utc(),
            rationale: RosterAuthorityTextV1::parse("Controlled explicit retained proof test")?,
        },
    )?;
    let approval = prepared.approval_bytes().to_vec();
    let digest = prepared.approval_digest().to_owned();
    let applied = store.apply_roster_source_enrollment_v1(prepared, &approval, &digest)?;
    check!(applied.written());
    check!(eq; store.store_format()?.lifecycle_revision, Some(8));
    let snapshot = store.db.snapshot();
    let enrollment = snapshot
        .get(&store.meta, ENROLLMENT)?
        .ok_or("retained enrollment")?
        .to_vec();
    let receipt = snapshot
        .get(&store.receipts, applied.receipt().operation.as_bytes())?
        .ok_or("retained receipt")?
        .to_vec();
    check!(eq; serde_json::from_slice::<Receipt>(&receipt)?, *applied.receipt());
    Ok((directory, store, enrollment, receipt))
}

#[test]
fn retained_public_enrollment_proof_validates_without_writes() -> TestResult {
    let (_directory, store, enrollment, receipt) = enrolled()?;
    let before = retained_state(&store)?;
    let identity = store.store_identity()?;
    let mut grant = Grant::new();
    check!(eq; proof::retained_enrollment_operation_v1(&enrollment, &mut grant)?, format!("{OPERATION_PREFIX}controlled-retained-proof"));
    proof::validate_roster_enrollment_proof_v1(&enrollment, &receipt, &identity, &mut grant)?;
    grant.ensure_available()?;
    proof::validate_roster_enrollment_proof_v1(
        &enrollment,
        &receipt,
        &identity,
        &mut Grant::new(),
    )?;
    check!(eq; retained_state(&store)?, before);
    Ok(())
}

#[test]
fn retained_enrollment_proof_mutations_refuse_exact_authority_and_poison() -> TestResult {
    let (_directory, store, enrollment, receipt) = enrolled()?;
    let (_other_directory, other, _writer) = fixture()?;
    let before = retained_state(&store)?;
    let identity = store.store_identity()?;
    for mutation in 0..7 {
        let mut held: EnrollmentRecord = serde_json::from_slice(&enrollment)?;
        let mut received: Receipt = serde_json::from_slice(&receipt)?;
        match mutation {
            0 => {
                held.command.rationale =
                    RosterAuthorityTextV1::parse("Changed unapproved rationale")?
            }
            1 => held.approval_digest = "0".repeat(64),
            2 => {}
            3 => received.operation.push_str("-changed"),
            4 => received.digest = "0".repeat(64),
            5 => received.appended = 1,
            6 => received.credited = true,
            _ => return Err("unexpected bounded mutation".into()),
        }
        let changed = serde_json::to_vec(&held)?;
        if mutation <= 2 {
            received.digest = codec::digest(&changed);
        }
        let mut grant = Grant::new();
        let expected_identity = if mutation == 2 {
            other.store_identity()?
        } else {
            identity.clone()
        };
        let result = proof::validate_roster_enrollment_proof_v1(
            &changed,
            &serde_json::to_vec(&received)?,
            &expected_identity,
            &mut grant,
        );
        check!(matches!(
            result,
            Err(StoreError::RosterSourceIssuance(Error::Corrupt(
                "enrollment authority mismatch"
            )))
        ));
        check!(grant.ensure_available().is_err());
        check!(proof::validate_roster_enrollment_proof_v1(
            &enrollment,
            &receipt,
            &identity,
            &mut grant
        )
        .is_err());
        check!(eq; retained_state(&store)?, before);
    }
    Ok(())
}

#[test]
fn retained_enrollment_proof_exact_byte_budget_and_one_short_are_typed() -> TestResult {
    let (_directory, store, enrollment, receipt) = enrolled()?;
    let before = retained_state(&store)?;
    let identity = store.store_identity()?;
    let mut measured = Grant::new();
    proof::validate_roster_enrollment_proof_v1(&enrollment, &receipt, &identity, &mut measured)?;
    let cost = measured.usage().encoded_bytes();
    check!(eq; cost, enrollment.len().checked_add(receipt.len()).and_then(|n| n.checked_mul(6)).ok_or("proof cost")?);
    let limit = ReplayLimits::SMALL.total_text_bytes;
    for short in 0..2 {
        let mut grant = Grant::new();
        grant.charge_bytes(
            limit
                .checked_sub(cost)
                .and_then(|n| n.checked_add(short))
                .ok_or("proof boundary")?,
        )?;
        let result = proof::validate_roster_enrollment_proof_v1(
            &enrollment,
            &receipt,
            &identity,
            &mut grant,
        );
        if short == 0 {
            result?;
            check!(eq; grant.usage().encoded_bytes(), limit);
            grant.ensure_available()?;
        } else {
            check!(
                matches!(result, Err(StoreError::EvidenceSubjectAttachment(crate::EvidenceSubjectAttachmentStoreError::Domain(
                EvidenceSubjectAttachmentError::Capacity { resource: "aggregate encoded bytes", needed, available }
            ))) if needed == limit + 1 && available == limit)
            );
            check!(grant.ensure_available().is_err());
        }
    }
    check!(eq; retained_state(&store)?, before);
    Ok(())
}
